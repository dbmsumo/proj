# Attendance-Management-System
A student management system developed using html5, css3, bootstrap, javascript, php &amp; mySQL
