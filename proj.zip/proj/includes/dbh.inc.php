<?php
  $con = mysqli_connect('localhost', 'dbms', 'sumo', 'attendance');
?>