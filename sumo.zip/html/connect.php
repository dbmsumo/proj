<?php
$host = "127.0.0.1";
$username = "dbms";
$pass = "sumo";

// Create connection
$con = mysqli_connect($host, $username, $pass, "attsystem");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
